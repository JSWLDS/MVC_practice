create
    definer = root@localhost procedure select_employee()
begin 
select * from employee;
end;

